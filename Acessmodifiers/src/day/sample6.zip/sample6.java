package day;

 
	interface I11{
		void add();	
		}
	interface I22{
		void  sub();
	}
	 interface I3 extends I11,I22{
		 void mul();
	 }
	 class pp1 implements I3{
		 public void add() {
			System.out.println("hi"); 
		 }
		 public void  sub() {
			 System.out.println("hello");
		 }
		 public void mul() {
			 System.out.println("welcome to nrcm");
		 }	 
		 }
		 public class sample6 extends pp1 {
		 public static void main(String[] args) {
			 sample6 s1=new sample6();
			 s1.add();
			 s1.sub();
			 s1.mul();
	 
	    
		 }
	 }	 

	
