package day;

public class sample2 {
	public static void main() {
		System.out.println("hii");
	 }
	public static void main(int a) {
		System.out.println(a);
	 }
	 public static void main(int a, int b) {
		System.out.println(a+b);
	 }
	 public static void main(int a,int b,double d1) {
		System.out.println(a+b-d1);
	}
	 
	public static void main(String[] args) {
		hello h1=new hello();
	    main .add();
		main.add(34);
		main.add(2,6);
		main.add(4,5,7.9);

		}

	}



